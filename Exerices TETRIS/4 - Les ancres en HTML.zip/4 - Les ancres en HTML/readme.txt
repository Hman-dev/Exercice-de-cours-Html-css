Objectif :
Insérer des ancres  pour améliorer l'accessibilité et la navigation dans un document html.

Travail à faire :
Dans cet exercice on va attribuer des ancres à quelques endroits de la page et par la suite on va créer des liens qui pointent vers ces ancres afin de faciliter la navigation de l'utilisateur sur la page.

Pour cela créer une page composée de 4 chapitres précédés de 4 liens. Chaque lien envoie vers un chapitre précis, pour simplifier on va considérer que chaque chapitre est composé d'un titre et d'un paragraphe (voir l'exemple dans le fichier resultat.png).

N'hésitez pas à utiliser google avec comme mot-clé "lorem ipsum" pour générer le texte de remplissage.
Conseil : Faîtes de longs paragraphes pour bien vous assurer que la navigation par les ancres fonctionne.
